const express = require('express');
const router = express.Router();

let platformObj;
router.get('/', (req, res) => {
    res.send({ status: "working" })
    console.log(platformObj.DB());
    
})
module.exports = function (platform) {
    platformObj = platform;
    return router;
}