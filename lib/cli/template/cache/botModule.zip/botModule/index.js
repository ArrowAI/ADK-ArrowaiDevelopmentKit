

class botModule {
    constructor(platformObject) {
        this.platformObject = platformObject;
    }
    async sendMessage(message, sessionId) { 
    }
    async  getNLP(message) {
    }

}

module.exports = botModule;