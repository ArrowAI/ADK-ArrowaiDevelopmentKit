import {
  Component,
  AfterViewInit,
  OnInit,
  EventEmitter,
  OnChanges,
  Input,
  Output,
  SimpleChanges,
  ChangeDetectorRef,
  ViewChild,
  ElementRef,
  OnDestroy,
} from '@angular/core';
import { Router } from '@angular/router';

import { BehaviorSubject, Subject, Subscription } from 'rxjs';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

import { NgbCarouselConfig } from '@ng-bootstrap/ng-bootstrap';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers: [NgbCarouselConfig],
})
export class AppComponent implements OnInit {
  constructor() {}
  expended: boolean = false;
  @Input() showList: boolean = false;
  @Output() genericTemplateEvent = new EventEmitter<any>();
  ngOnInit(): void {}
  webChatElements: any[] = [];

  elementClicked() {
    this.showList = false;
    this.expended = false;
    this.genericTemplateEvent.next('buttonClicked');
  }
  expendWindow() {
    this.expended = true;
    this.genericTemplateEvent.next('expendWindow');
  }
  shrinkWindow() {
    this.genericTemplateEvent.next('shrinkWindow');
    this.expended = false;
  }
}
