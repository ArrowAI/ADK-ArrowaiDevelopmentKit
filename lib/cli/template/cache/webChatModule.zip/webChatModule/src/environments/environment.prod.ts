// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
	production: true,
	FACEBOOK_GRAPH: "https://graph.facebook.com/v3.2",
	isMockEnabled: true, // You have to switch this, when your real back-end is done
	authTokenKey: 'authce9d77b308c149d5992a80073637e4d5',
	firebase: {
		apiKey: "AIzaSyDxpOGsvGZyzhGhrsIzn0rCuefIZiDHC_E",
		authDomain: "arrowai-kubernetes.firebaseapp.com",
		databaseURL: "https://arrowai-kubernetes.firebaseio.com",
		projectId: "arrowai-kubernetes",
		storageBucket: "arrowai-kubernetes.appspot.com",
		messagingSenderId: "398547126702",
		appId: "1:398547126702:web:7880fd588527e15b00603f",
		measurementId: "G-CX7NVL5ZXG"
	  },
	// firebase: {
	// 	apiKey: "AIzaSyBB0IkQNDg0hOgL3ZTv_LeyG4-leOw6XmQ",
	// 	authDomain: "arroaaimainlocal.firebaseapp.com",
	// 	databaseURL: "https://arroaaimainlocal.firebaseio.com",
	// 	projectId: "arroaaimainlocal",
	// 	storageBucket: "arroaaimainlocal.appspot.com",
	// 	messagingSenderId: "1060626291067",
	// 	appId: "1:1060626291067:web:27f97279bf25e80b8d85de"
	// },
	N8N_SERVER:'https://apiserver.arrowai.in/workflow',
	INTERACTION_ENGINE: 'https://interaction.arrowai.in',
	SOCKET_SERVER: "https://interaction.arrowai.in",
	CONSOLE_URL: 'https://console.arrowai.in',
	DREAM_FACTORY_URL: 'https://api.arrowai.in/api/v2/chat_developer',
	API_SERVER: "https://apiserver.arrowai.in",
	API_SERVER_LOCAL: 'https://apiserver.arrowai.in',
	AIHR_SERVER: "https://aihr.arrowai.in",
	CHAT_ENGINE: "https://chatengine.arrowai.in",
	CHAT_COMPONENT_TEST_URL:"http://localhost:3000",
	DASHBOARD_API:"https://dashboard-api-790-srnzdkes3a-as.a.run.app/api",
	ARROW_CHAT_URL:"",
	EVENT_SERVER:"https://event.arrowai.in",
	CLAUD_STORAGE_URL:'https://asia-south1-arrowai-kubernetes.cloudfunctions.net'

	

};

///chats/app/clear/fast/bots?botId=5e78c41d4fbc350d00000001


/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.