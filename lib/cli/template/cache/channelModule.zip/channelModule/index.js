/**
 * TODO:Change To Your Channel Name
 *for more info :https://arrowai.gitbook.io/api/channels-1/create-custom-channel
 */
class DemoChannel {
    constructor(platformObj) {
        this.platformObj = platformObj
    }
    
    receivedApiMessage(message, applicationId, integrationId) {
        return new Promise(async (resolve, reject) => {
            resolve(message);
        })
    };
    sendMessage(message) {
    };
}

module.exports = DemoChannel;